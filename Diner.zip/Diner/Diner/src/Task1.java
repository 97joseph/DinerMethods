import java.util.Arrays;

public class Task1 {

  public static void main (String [] args) {
      Diner.createPartyFor(args);
      Diner.listAllTheDiners();
  }


}
