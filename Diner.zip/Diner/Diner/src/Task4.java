public class Task4 {

  public static void main (String [] args) {
      Diner.createPartyFor(args);
      Diner.takeEveryonesOrder();
      Diner.listEveryonesOrder();
      Diner.getAnotherRound();
      Diner.listEveryonesOrder();
      Diner.dealWithTheBill();
  }

//Methods

}
