public class Task3 {

  public static void main(String[] args) {
    Diner.createPartyFor(args);
    Diner.takeEveryonesOrder();
    Diner.listEveryonesOrder();
    Diner.dealWithTheBill();
  }
  // Methods
}
