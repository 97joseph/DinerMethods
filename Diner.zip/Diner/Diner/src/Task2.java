public class Task2 {

  public static void main(String[] args) {
    Diner.createPartyFor(args);
    Diner.takeEveryonesOrder();
    Diner.listEveryonesOrder();
  }

  // Methods

}
